System.register(["angular2/core", "ag-grid-ng2/main", "./order.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, main_1, order_service_1;
    var DetailsGridComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (main_1_1) {
                main_1 = main_1_1;
            },
            function (order_service_1_1) {
                order_service_1 = order_service_1_1;
            }],
        execute: function() {
            DetailsGridComponent = (function () {
                function DetailsGridComponent(_orderService) {
                    this._orderService = _orderService;
                    this.updatedTotal = new core_1.EventEmitter();
                    // we pass an empty gridOptions in, so we can grab the api out
                    this.gridOptions = {};
                    this.createColumnDefs();
                    this.loadData();
                }
                DetailsGridComponent.prototype.ngOnChanges = function () {
                    this.loadData();
                };
                DetailsGridComponent.prototype.createColumnDefs = function () {
                    this.columnDefs = [
                        {
                            headerName: "OrderDetailsId", field: "orderDetailsId", hide: true
                        },
                        {
                            headerName: "Product",
                            children: [
                                {
                                    headerName: "ID", field: "productId",
                                    width: 80, pinned: true,
                                    cellClass: "unselectable"
                                },
                                {
                                    headerName: "Name", field: "productName",
                                    width: 150, pinned: true,
                                    cellClass: "unselectable"
                                }
                            ]
                        },
                        {
                            headerName: "Quantity", field: "quantity", width: 100, editable: true,
                            newValueHandler: this.onQuantityValueChanged.bind(this)
                        },
                        {
                            headerName: "Price",
                            field: "price",
                            cellClass: "rightJustify unselectable",
                            width: 100,
                            cellRenderer: function (params) {
                                return "$" + params.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                            }
                        },
                        {
                            headerName: "Total",
                            field: "total",
                            cellClass: "rightJustify unselectable",
                            width: 100,
                            cellRenderer: function (params) {
                                return "$" + params.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                            }
                        },
                        {
                            headerName: "Comments", field: "comments", width: 600, editable: true,
                            newValueHandler: this.onCommentsValueChanged.bind(this)
                        }
                    ];
                };
                DetailsGridComponent.prototype.loadData = function () {
                    var _this = this;
                    if (this.itemInfo) {
                        this._orderService.getOrderDetails(this.itemInfo.id)
                            .then(function (orderDetails) { return _this.rowData = orderDetails; });
                    }
                };
                DetailsGridComponent.prototype.updateOrderTotal = function () {
                    var newTotal = this.rowData.reduce(function (previousValue, currentValue) {
                        return previousValue + currentValue.total;
                    }, 0);
                    this.updatedTotal.emit(newTotal);
                };
                DetailsGridComponent.prototype.onQuantityValueChanged = function (params) {
                    var _this = this;
                    var newValue = Number(params.newValue);
                    if (isNaN(newValue) || newValue === params.oldValue) {
                        params.data.quantity = params.oldValue;
                        return;
                    }
                    params.data.quantity = newValue;
                    params.data.total = newValue * params.data.price;
                    this._orderService.updateOrderDetails(params.data)
                        .then(function () {
                        _this.updateItem(params.data);
                        _this.updateOrderTotal();
                    }).catch(function () {
                        params.data.quantity = params.oldValue;
                        params.data.total = params.oldValue * params.data.price;
                        _this.updateItem(params.data);
                        console.log("Save failed");
                    });
                };
                DetailsGridComponent.prototype.onCommentsValueChanged = function (params) {
                    var _this = this;
                    if (params.newValue === params.oldValue) {
                        return;
                    }
                    params.data.comments = params.newValue;
                    this._orderService.updateOrderDetails(params.data)
                        .catch(function () {
                        params.data.comments = params.oldValue;
                        _this.updateItem(params.data);
                        console.log("Save failed");
                    });
                };
                DetailsGridComponent.prototype.updateItem = function (updatedItem) {
                    var id = updatedItem.productId;
                    var updatedNodes = [];
                    this.gridOptions.api.forEachNode(function (node) {
                        var data = node.data;
                        if (data.productId === id) {
                            data.total = updatedItem.total;
                            data.quantity = updatedItem.quantity;
                            data.comments = updatedItem.comments;
                            updatedNodes.push(node);
                        }
                    });
                    this.gridOptions.api.refreshCells(updatedNodes, ["total", "quantity", "comments"]);
                };
                DetailsGridComponent = __decorate([
                    core_1.Component({
                        selector: "details-grid",
                        templateUrl: "../html/details-grid.html",
                        directives: [main_1.AgGridNg2],
                        inputs: ["itemInfo"],
                        outputs: ["updatedTotal"],
                    }), 
                    __metadata('design:paramtypes', [order_service_1.OrderService])
                ], DetailsGridComponent);
                return DetailsGridComponent;
            }());
            exports_1("DetailsGridComponent", DetailsGridComponent);
        }
    }
});
//# sourceMappingURL=details-grid.component.js.map