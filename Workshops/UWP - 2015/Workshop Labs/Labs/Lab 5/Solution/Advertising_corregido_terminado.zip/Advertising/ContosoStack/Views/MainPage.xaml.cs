﻿using System;
using Windows.ApplicationModel.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Microsoft.Advertising.WinRT.UI;
using ContosoStack.Models;


namespace ContosoStack.Views
{
    public sealed partial class MainPage : Page
    {

        private InterstitialAd _interstitialAd;

        public MainPage()
        {
            this.InitializeComponent();
            this.ViewModel = this.DataContext as ViewModels.MainPageViewModel;
            CoreApplication.GetCurrentView().TitleBar.ExtendViewIntoTitleBar = true;
            Window.Current.SetTitleBar(AppTitle);

            if (this.ViewModel.ShowAds)
            {
                // initialize the interstitial class
                _interstitialAd = new InterstitialAd();


                // wire up all 4 events
                _interstitialAd.AdReady += interstitialAd_AdReady;
                _interstitialAd.Cancelled += interstitialAd_Cancelled;
                _interstitialAd.Completed += interstitialAd_Completed;
                _interstitialAd.ErrorOccurred += interstitialAd_ErrorOccurred;

                RequestAd();
            }
            else
            {
                // start normally
            }

        }

        private async void interstitialAd_ErrorOccurred(object sender, AdErrorEventArgs e)
        {
            // handle errors here
            var dialog = new ContentDialog
            {
                Title = "An Error",
                Content = e.ErrorMessage,
                PrimaryButtonText = "OK",
                IsPrimaryButtonEnabled = true
            };

            await dialog.ShowAsync();

        }

        private void interstitialAd_Completed(object sender, object e)
        {
            // raised when the user has watched the full video
            this.ViewModel.ViewedFullInterstitial = true;
        }

        private async void interstitialAd_Cancelled(object sender, object e)
        {
            // raised if the user interrupts the video          
            //var dialog = new ContentDialog
            //{
            //    Title = "Ad Interrupted",
            //    Content = "You must watch the complete ad!",
            //    PrimaryButtonText = "OK",
            //    IsPrimaryButtonEnabled = true
            //};

            //await dialog.ShowAsync();

            //RequestAd();

        }

        private void interstitialAd_AdReady(object sender, object e)
        {

            // This is just for demoing - you should handle this differently in a production app
            if (_interstitialAd.State == InterstitialAdState.Ready)
            {
                _interstitialAd.Show();
            }

        }

        private void RequestAd()
        {
            _interstitialAd.RequestAd(AdType.Video, DemoAds.VideoAdUnit.AppId, DemoAds.VideoAdUnit.AdUnitId);
        }

        ViewModels.MainPageViewModel ViewModel { get; set; }

        private async void TodoItem_ItemClicked(object sender, ItemClickEventArgs e)
        {
            this.TodoEditorDialog.DataContext = e.ClickedItem;
            await this.TodoEditorDialog.ShowAsync();
        }

        private async void List_Tapped(object sender, Windows.UI.Xaml.Input.TappedRoutedEventArgs e)
        {
            var textBlock = sender as TextBlock;
            var data = textBlock.DataContext as ViewModels.TodoListViewModel;
            this.ListEditorDialog.DataContext = data.TodoList;
            this.ListEditorDialog.SecondaryButtonCommand = this.ViewModel.RemoveListCommand;
            this.ListEditorDialog.SecondaryButtonCommandParameter = data;
            await this.ListEditorDialog.ShowAsync();
        }

        private void TextBox_KeyDown(object sender, Windows.UI.Xaml.Input.KeyRoutedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (e.Key == Windows.System.VirtualKey.Enter
                && !string.IsNullOrEmpty(textBox.Text)
                && textBox.Text.Length > 3)
            {
                e.Handled = true;
                var list = textBox.DataContext as ViewModels.TodoListViewModel;
                list.AddCommand.Execute(textBox.Text);
                textBox.Text = string.Empty;
                textBox.Focus(Windows.UI.Xaml.FocusState.Programmatic);
            }
        }



    }
}
