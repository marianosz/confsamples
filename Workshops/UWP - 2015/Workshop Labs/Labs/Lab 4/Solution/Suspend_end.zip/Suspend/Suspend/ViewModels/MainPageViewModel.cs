﻿using Windows.UI.Xaml.Navigation;
using Suspend.Mvvm;
using System.Collections.Generic;

namespace Suspend.ViewModels
{
    public class MainPageViewModel : ViewModelBase
    {
        public MainPageViewModel()
        {
            this.MyParameter = "Set from constructor";
            if (Windows.ApplicationModel.DesignMode.DesignModeEnabled)
            {
                Value = "Design value";
            }
        }
        public override void OnNavigatedTo(string parameter, NavigationMode mode, IDictionary<string, object> state)
        {
            this.MyParameter = parameter?.ToString() ?? "Empty";
        }

        private string _myParameter = default(string);
        public string MyParameter { get { return _myParameter; } set { Set(ref _myParameter, value); } }

        private string _Value = "Hello Template 10";
        public string Value { get { return _Value; } set { Set(ref _Value, value); } }
    }
}
