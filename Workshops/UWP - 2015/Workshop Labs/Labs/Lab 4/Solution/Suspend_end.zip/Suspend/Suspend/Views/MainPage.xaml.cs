﻿using Windows.UI.Core;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace Suspend.Views
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
            this.DataContextChanged += (s, e) => { ViewModel = DataContext as ViewModels.MainPageViewModel; };
        }

        // Strongly-typed view models enable x:Bind
        public ViewModels.MainPageViewModel ViewModel { get; set; }

        private void GotoDetail(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            var app = App.Current as Common.BootStrapper;
            app.NavigationService.Navigate(typeof(Views.DetailPage), this.ViewModel.Value);
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            SystemNavigationManager.GetForCurrentView().AppViewBackButtonVisibility = Frame.CanGoBack ? AppViewBackButtonVisibility.Visible : AppViewBackButtonVisibility.Collapsed;

            base.OnNavigatedTo(e);
        }

    }
}
