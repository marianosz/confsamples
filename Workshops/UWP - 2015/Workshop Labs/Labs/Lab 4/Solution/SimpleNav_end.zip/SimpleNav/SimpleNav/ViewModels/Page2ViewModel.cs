﻿using SimpleNav.Mvvm;
using Windows.UI.Xaml.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleNav.ViewModels
{
    public class Page2ViewModel : ViewModelBase
    {

        public Page2ViewModel()
        {
            this.MyParameter = "Set from constructor";
        }

        public override void OnNavigatedTo(string parameter, NavigationMode mode, IDictionary<string, object> state)
        {
            this.MyParameter = parameter?.ToString() ?? "Empty";
        }

        private string _myParameter = default(string);
        public string MyParameter { get { return _myParameter; } set { Set(ref _myParameter, value); } }

    }
}
