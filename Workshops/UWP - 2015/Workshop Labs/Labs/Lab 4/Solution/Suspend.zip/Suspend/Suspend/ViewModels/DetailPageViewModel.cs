﻿using Suspend.Mvvm;
using Windows.UI.Xaml.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Suspend.ViewModels
{
    public class DetailPageViewModel : ViewModelBase
    {

        private string _FirstName = default(string);
        public string FirstName { get { return _FirstName; } set { Set(ref _FirstName, value); } }

        private string _LastName = default(string);
        public string LastName { get { return _LastName; } set { Set(ref _LastName, value); } }

        private string _Email = default(string);
        public string Email { get { return _Email; } set { Set(ref _Email, value); } }

    }
}
