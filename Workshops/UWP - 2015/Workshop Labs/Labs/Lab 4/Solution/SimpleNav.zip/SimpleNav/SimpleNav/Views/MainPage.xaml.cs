﻿using Windows.UI.Xaml.Controls;

namespace SimpleNav.Views
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
            this.DataContextChanged += (s, e) => { ViewModel = DataContext as ViewModels.MainPageViewModel; };
        }

        // Strongly-typed view models enable x:Bind
        public ViewModels.MainPageViewModel ViewModel { get; set; }

    }
}