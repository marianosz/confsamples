﻿namespace ElementName.ViewModels
{
    public class MainPageViewModel : Mvvm.ViewModelBase
    {
        public MainPageViewModel()
        {
            if (Windows.ApplicationModel.DesignMode.DesignModeEnabled)
            {
                Value = "Design value";
            }
        }
        private string _Value = "Hello Template 10";
        public string Value { get { return _Value; } set { Set(ref _Value, value); } }
    }

}
