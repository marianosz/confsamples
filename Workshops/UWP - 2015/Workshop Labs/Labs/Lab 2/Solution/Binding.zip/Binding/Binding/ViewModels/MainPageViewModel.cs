﻿namespace Binding.ViewModels
{
    public class MainPageViewModel : Mvvm.ViewModelBase
    {
    }
}
