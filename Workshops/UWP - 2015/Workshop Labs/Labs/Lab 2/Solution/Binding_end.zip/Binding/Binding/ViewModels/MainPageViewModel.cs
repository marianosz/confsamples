﻿using System.Collections.ObjectModel;

namespace Binding.ViewModels
{
    public class MainPageViewModel : Mvvm.ViewModelBase
    {
        public MainPageViewModel()
        {
            for (int i = 0; i < 100; i++)
            {
                var item = new Models.TodoItem
                {
                    Title = string.Format("Task Title {0}", i)
                };
                this.Items.Add(item);

            }
        }
        public ObservableCollection<Models.TodoItem> Items { get; private set; } = new ObservableCollection<Models.TodoItem>();
    }

}