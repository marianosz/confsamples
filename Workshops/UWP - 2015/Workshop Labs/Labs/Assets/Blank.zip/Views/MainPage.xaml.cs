﻿using $safeprojectname$.ViewModels;
using Windows.UI.Xaml.Controls;

namespace $safeprojectname$.Views
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
            DataContextChanged += (s, e) => ViewModel = DataContext as MainPageViewModel;
        }

        // strongly-typed view models enable x:bind
        public MainPageViewModel ViewModel { get; set; }
    }
}