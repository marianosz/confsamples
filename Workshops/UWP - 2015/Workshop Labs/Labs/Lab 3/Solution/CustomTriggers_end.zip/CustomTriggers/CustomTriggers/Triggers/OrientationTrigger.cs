﻿using CustomTriggers.Mvvm;
using Windows.UI.ViewManagement;
using Windows.UI.Xaml;
namespace CustomTriggers.Triggers
{
    public class OrientationTrigger : StateTriggerBase
    {
        public OrientationTrigger()
        {
            var win = Window.Current;
            WeakEvent.Subscribe<WindowSizeChangedEventHandler>(win, nameof(win.SizeChanged), (sender, e) => CalculateState());
            CalculateState();
        }

        private void CalculateState()
        {
            var currentOrientation = ApplicationViewOrientation.Landscape;
            var window = Window.Current;

            currentOrientation = window.Bounds.Width >= window.Bounds.Height ? ApplicationViewOrientation.Landscape : ApplicationViewOrientation.Portrait;

            SetActive(currentOrientation == orientation);
        }

        private ApplicationViewOrientation orientation;
        public ApplicationViewOrientation Orientation
        {
            get { return orientation; }
            set
            {
                if (orientation != value)
                {
                    orientation = value;
                    CalculateState();
                }
            }
        }


    }
}
