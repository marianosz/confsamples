﻿using System;
using System.Threading.Tasks;
using AdaptiveUI.Common;
using Windows.ApplicationModel.Activation;

namespace AdaptiveUI
{
    sealed partial class App : Common.BootStrapper
    {
        public App()
        {
            InitializeComponent();
        }

        public override Task OnStartAsync(StartKind startKind, IActivatedEventArgs args)
        {
            NavigationService.Navigate(typeof(Views.MainPage));
            return Task.FromResult<object>(null);
        }
    }
}
