﻿using Windows.UI.Xaml.Controls;

namespace $safeprojectname$.Controls
{
    public sealed partial class TodoItemEditor : ContentDialog
    {
        public TodoItemEditor()
        {
            this.InitializeComponent();
        }
    }
}
