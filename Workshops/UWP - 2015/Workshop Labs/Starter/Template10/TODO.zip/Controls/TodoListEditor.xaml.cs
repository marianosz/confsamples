﻿using Windows.UI.Xaml.Controls;

namespace $safeprojectname$.Controls
{
    public sealed partial class TodoListEditor : ContentDialog
    {
        public TodoListEditor()
        {
            this.InitializeComponent();
        }
    }
}
